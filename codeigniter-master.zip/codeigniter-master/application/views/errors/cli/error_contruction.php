<!DOCTYPE html>
<html>
<head>
	<title>Trang web đang được xây dựng</title>
</head>
<body>
<div style="width: 100%; text-align: center;">
	<img style="margin:auto;" src="<?php echo $base_url; ?>/public/images/404/under_construction.jpg"><br> <br>
	<a href="<?php echo $base_url; ?>home"><h1>Home</h1></a>
</div>
</body>
</html>
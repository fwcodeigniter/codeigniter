<div class="container">
    <h1> Đây là trang quản trị </h1>
</div>
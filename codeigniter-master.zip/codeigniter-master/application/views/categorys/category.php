
<?php 
	echo "Danh sách sản phẩm theo danh mục";
	var_dump($data);
 ?>
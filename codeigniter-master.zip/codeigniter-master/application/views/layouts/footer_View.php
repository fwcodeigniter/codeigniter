<footer id="footer"><!--Footer-->
		<div class="footer-top">
			<div class="container">
				<h1>Đồ án môn học Chuyên đề Framework </h1>

			</div>
		</div>
		
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<div class="col-sm-3">
						<div class="single-widget">
							<h2>Giáo viên hướng dẫn</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Trương Bá Thái</a></li>
								
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="single-widget">
							<h2>Sinh viên thực hiện</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Hoàng Thiện</a></li>
								<li><a href="#">Nguyễn Ngọc Thúy</a></li>
								<li><a href="#">Võ Khắc Hoàng Phương</a></li>
								<li><a href="#">Trần Tấn Vinh</a></li>
								<li><a href="#">Nguyễn Nam Chinh</a></li>
								<li><a href="#">Quang Tiên Đạt</a></li>
							</ul>
						</div>
					</div>
					
					<div class="col-sm-2">
						<div class="single-widget">
							<h2>Tài liệu tham khảo</h2>
							<ul class="nav nav-pills nav-stacked">
								<li><a href="#">Freetuts.net</a></li>
								<li><a href="#">hocphp.info</a></li>
								
							</ul>
						</div>
					</div>
					
					<div class="col-sm-3 col-sm-offset-1">
						<div class="single-widget">
							<h2>About Project</h2>
							<form action="#" class="searchform">
								<input type="text" placeholder="Your email address" />
								<button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
								<p>Get the most recent updates from <br />our site and be updated your self...</p>
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © 2013 E-SHOPPER Inc. All rights reserved.</p>
					<p class="pull-right">Designed by <span><a target="_blank" href="">Themeum</a></span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	

  
    <script src="<?php echo $base_url; ?>public/js/jquery.js"></script>
	<script src="<?php echo $base_url; ?>public/js/bootstrap.min.js"></script>
	<script src="<?php echo $base_url; ?>public/js/jquery.scrollUp.min.js"></script>
	<script src="<?php echo $base_url; ?>public/js/price-range.js"></script>
    <script src="<?php echo $base_url; ?>public/js/jquery.prettyPhoto.js"></script>
    <script src="<?php echo $base_url; ?>public/js/notify.min.js"></script>
    <script src="<?php echo $base_url; ?>public/js/main.js"></script>
    <script src="<?php echo $base_url; ?>public/js/thien.js"></script>
    <script type="text/javascript">
    	function file_change(f,id){
		    var reader = new FileReader();
		    reader.onload = function (e) {
		       	// var img = document.getElementById(id);
		        id.src = e.target.result;
		        id.style.display = "inline";
	    };
	    reader.readAsDataURL(f.files[0]);
		}
		function notify_success(){
			var txt = document.getElementById('success').innerHTML;
			// alert(txt);
			if (txt) {

				$.notify(txt,"success");
			}
			var txt = document.getElementById('fail').innerHTML;
			// alert(txt);
			if (txt) {
				$.notify(txt,"error");
			}
		}

		$(document).ready(notify_success);
    </script>
</body>
</html>
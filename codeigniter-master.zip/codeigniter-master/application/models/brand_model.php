<?php 
	/**
	* 
	*/
	class Brand_model extends MY_Model
	{
		public $table = 'brand';
		
	}
 ?>
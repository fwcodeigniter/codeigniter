<?php
Class transaction_model extends MY_Model
{
    var $table = 'transaction';
}
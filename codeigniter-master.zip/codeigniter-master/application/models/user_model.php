<?php 
	/**
	* 
	*/
	class User_model extends MY_Model
	{
		public $table = 'user';
		
	}
 ?>